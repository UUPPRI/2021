---
layout: "urls"
---

| [Arsip Lama Peraturan NKRI](https://uu.vlsm.org/)     | [00-README-ls-alR.txt](00-README-ls-alR.txt)    | [IDX --- Indonesia Stock Exchange 2021](IDX/) |
| [KEPPRES --- Keputusan Presiden 2021](KEPPRES/)       | [PERPRES --- Peraturan Presiden 2021](PERPRES/) | [PP --- Peraturan Pemerintah 2021](PP/) |
| [UI --- Universitas Indonesia 2021](UI/) |

